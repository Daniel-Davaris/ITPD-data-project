import matplotlib.pyplot as plt

name = "visual"
plt.figure(figsize=(7, 4))
plt.plot([20, 8, 3, 4], [71, 20, 8, 20])
plt.title("Sample Line Plot")
plt.xlabel("X-axis")
plt.ylabel("Y-axis")
plt.grid(True)
plt.show()