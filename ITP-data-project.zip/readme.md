# Usage

1. Run ```git lfs pull``` to pull the datasets stored within git large file storage (LFS) used in this project in your local repo.

2. Run ```pip install -r requirements.txt``` to install the required packages for this project

